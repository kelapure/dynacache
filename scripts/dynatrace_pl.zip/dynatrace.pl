#!/usr/bin/perl
# Dynacache invalidations
# voldman@ca.ibm.com
#
# Version Control
# 0.901     Base 1


use strict;
use warnings;
#use diagnostics;

use Data::Dumper;
use Getopt::Long;
use File::Spec;

BEGIN {
   # Set environment variable = BASE_DIR
   my $EXE_FILE  = $0;

   $EXE_FILE =~ s/\\/\//g;
   my $EXE_PATH = $EXE_FILE;

   $EXE_FILE =~ s/.*\///g;
   $EXE_PATH =~ s/\/($EXE_FILE)//g;

   $ENV{BASE_DIR} = File::Spec->rel2abs( $EXE_PATH );

   push(@INC,"$ENV{BASE_DIR}");
}

# WASLog Objects
use WAS::LogFile;

# ------------------------------------------------------------------------------------------
#
# Cause Translator
#
# ------------------------------------------------------------------------------------------
my %invalidationCause = (
   0 => 'UNSET',
   1 => 'DIRECT',
   2 => 'LRU',
   3 => 'TIMEOUT',
   6 => 'INACTIVITY',
   7 => 'DISK_GARBAGE_COLLECTOR',
   8 => 'DISK_OVERFLOW'
);

sub getCause {
   my $cause = shift;
   return $invalidationCause{$cause} if $invalidationCause{$cause};
   return $cause;
}

# ------------------------------------------------------------------------------------------
#
# Source Translator
#
# ------------------------------------------------------------------------------------------
my %invalidationSource = (
   1 => 'MEMORY',
   2 => 'REMOTE',
   3 => 'DISK',
   4 => 'NOOP',
   5 => 'LOCAL'
);

sub getSource {
   my $source = shift;
   return $invalidationSource{$source} if $invalidationSource{$source};
   return $source;
}

# ------------------------------------------------------------------------------------------
#
# logMessage
#
# ------------------------------------------------------------------------------------------
sub logMessage {
   my $msg = shift;
   print "-----> $msg\n";
}

# ------------------------------------------------------------------------------------------
#
# usage info
#
# ------------------------------------------------------------------------------------------
#no warnings;
sub showUsage() {
   print STDOUT << "EOF";

usage: $0 [OPTIONS] FILE

Trace should contain this trace:
  com.ibm.ws.cache.*=all:com.ibm.ws.drs.*=all

Tool looks for this line:
  Cache.remove() cacheName=baseCache id=Customers cause=1 source=2

Filtering Options:

-i  | --instance CACHE_INSTANCE
  Tool uses the contains reg ex

-c  | --cause CAUSE
  Use either number of string
   0    UNSET
   1    DIRECT
   2    LRU
   3    TIMEOUT
   6    INACTIVITY
   7    DISK_GARBAGE_COLLECTOR
   8    DISK_OVERFLOW

-s  | --source SOURCE
   1    MEMORY
   2    REMOTE
   3    DISK
   4    NOOP
   5    LOCAL

Output:
  - FILE.inv.csv
  - FILE.inv.nonum.csv

  FILE.inv.nonum.csv can be used for grouping

EOF
  exit;
}
use warnings;

if ( $#ARGV+1 < 1 ) {
   showUsage();
}

# ------------------------------------------------------------------------------------------
#
# Parameters
#
# ------------------------------------------------------------------------------------------

my $help;
my $instance;
my $cause;
my $source;

my $opt = GetOptions ( 'help|?'       => \$help,
                       'i|instance=s' => \$instance,
                       'c|cause=s'    => \$cause,
                       's|source=s'   => \$source );

showUsage() unless $opt;
showUsage() if ( $help );

my $file = pop @ARGV;

showUsage() unless $file;

# ------------------------------------------------------------------------------------------
#
# Main
#
# ------------------------------------------------------------------------------------------

logMessage "Grepping file: $file";

logMessage "Filtering by instance=$instance" if ($instance);

if ($cause) {
  $cause  = getCause($cause);
  logMessage "Filtering by cause=$cause";
}

if ($source) {
  $source = getSource($source);
  logMessage "Filtering by source=$source";
}

my @files = glob($file);
my $processed = 0;

foreach my $cf (@files)  {

   if ( -r $cf ) {

      logMessage "Processing: $cf";

      my $noExtFile = $cf;
      $noExtFile =~ s/(.*)(.log|.txt)$/$1/i;

      my $invLog      = $noExtFile . ".inv.csv";
      my $invNoNumLog = $noExtFile . ".inv.nonum.csv";

      logMessage "Writing $invLog";
      logMessage "Writing $invNoNumLog";

      open InvLog,         ">" . $invLog        or die "Cannot create $invLog        --> $!\n";
      open InvNoNumLog,   ">" . $invNoNumLog   or die "Cannot create $invNoNumLog   --> $!\n";

      print InvLog       "\"Cache Instance\",\"Cache ID\",\"Cause\",\"Source\"\n";
      print InvNoNumLog  "\"Cache Instance\",\"Cache ID\",\"Cause\",\"Source\"\n";

      # creates object
      my $log =  eval { new WAS::LogFile($cf); }  or die ($@);
      my $invCount =  0;

      while ( ( my $entry = $log->nextEntry ) ) {

        if ( $entry ) {

          #Cache         3   Cache.remove() cacheName=baseCache id=com.ibm.commerce.accesscontrol.policymanager.ParentOrganizationCacheCmdImpl:getResourceOwner=7000000000000010510 cause=6 source=5
          if ( $entry->message =~ m/Cache.remove\(\) cacheName=(.*) id=(.*) cause=(\d) source=(\d)/) {

            my $cacheName = $1;
            my $cacheId   = $2;
            my $invCause  = getCause($3);
            my $invSource = getSource($4);

            #
            # Filter by instance
            #
            if (  $instance and ( not $cacheName or not $cacheName =~ m/$instance/i  )) {
               next;
            }

            #
            # Filter by cause
            #
            if (  $cause and ( not $invCause or not $invCause =~ m/$cause/i  )) {
               next;
            }

            #
            # Filter by source
            #
            if (  $source and ( not $invSource or not $invSource =~ m/$source/i  )) {
               next;
            }

            print InvLog       "\"$cacheName\",\"$cacheId\",\"$invCause\",\"$invSource\"\n";

            my $cacheIdNoNum = $cacheId;
            $cacheIdNoNum =~ s/\d+/__num__/g;

            print InvNoNumLog  "\"$cacheName\",\"$cacheIdNoNum\",\"$invCause\",\"$invSource\"\n";
						$invCount += 1;
						
          }
        }
      }
      
      logMessage "Process $cf file. Found $invCount invalidations";

      # file closes
      $log->close;

      close InvLog;
      close InvNoNumLog;

      $processed++;

   } else {
      logMessage "ERROR: Cannot read $cf: $!";
   }
}

logMessage "File not found $file" unless $processed > 0 ;
logMessage "Done.";

# end
