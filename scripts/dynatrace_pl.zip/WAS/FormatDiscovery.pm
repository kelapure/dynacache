#!/usr/bin/perl

package WAS::FormatDiscovery;

use strict;
use warnings;
use Data::Dumper;

use WAS::LogFormat;
use WAS::DefaultLogFormat;
use WAS::SearsLogFormat;

# Formats to support
#  Standard Short
#  Standard Long
#  Sears jsessionId

# ------------------------------------------------------------------------------------------
#
# findFormat
#
# ------------------------------------------------------------------------------------------
sub findFormat {

   my ( $class, $logfile ) = @_;
   my $format;
   
   open LOG, "<" . $logfile  or die "Error, unable to open $logfile, $!\n";

   while ( <LOG> ) {
   	
      my $entry = eval { new WAS::LogFormat(); }  or die ($@);

      # locate the first log entry
      if ( $entry->isNewEntry($_) ) {
      	
      	

         # [6/5/07 11:07:58:690 CDT]  INFO  0000003a  ETMKFyE2xmkVtdGmqKYrO3p  com.shc.ecom.shoppingcart  Order Id 131501
         # [10/5/06 20:37:10:724 EDT] 160d9b17 ManagerAdmin  I TRAS0017I: The startup trace state is *=all=disabled.

         # Rules:
         #   Find the level ; if it is one char then it is default

         my $level = $1 if ( /\S+\s\S+\s\S+\]\s+\S+\s+\S+\s+(\S+)\s+/ );

         # print "level = " . $level . " len = " . length($level)  . "\n";

         if ( $level and length($level) == 1 )  {
            $format = eval { new WAS::DefaultLogFormat(); }  or die ($@);
            print "-----> Log file format: Default - short\n";
         } else {
            $format = eval { new WAS::SearsLogFormat(); }   or die ($@);
            print "-----> Log file format: Custom - Sears\n";

         }

         last;
      }
   }

   close LOG;

   if ( ! $format ) {
      print "-----> ERROR: Unrecognized Format. Exiting";
      die;
   }

   return $format;
}


1;
