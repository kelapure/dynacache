#!/usr/bin/perl

package WAS::LogEntry;

use strict;
use Data::Dumper;
use DateTime;


# ------------------------------------------------------------------------------------------
#
# new
#
# ------------------------------------------------------------------------------------------
sub new {

   my ($class) = @_;

    my $self = {
        _date        => undef,
        _time        => undef,
        _threadId    => undef,
        _component   => undef,
        _severity    => undef,
        _message     => undef,
        _logText     => undef,
        _jsessionId  => undef,
        _dateTime		=> undef
    };

    bless $self, $class;

    return $self;
}

#[6/5/07 11:07:58:690 CDT]  INFO  0000003a  ETMKFyE2xmkVtdGmqKYrO3y  com.shc.ecom.shoppingcart  Order Id 131501
#[2/8/07 14:40:33:284 CST] 000000f6 ServletWrappe E   SRVE0014E: Uncaught service() exception root cause /BassProStorefrontAssetStore/ShoppingArea/CheckoutSection/StandardCheckoutSubsection/OrderConfirmationDisplayBody.jsp: java.lang.reflect.InvocationTargetException

# [18/Mar/2008:23:14:33 -0400] access log format

# wasadm60@darwin [/usr/WebSphere60/AppServer/profiles/stress001/logs/server1]:

# ------------------------------------------------------------------------------------------
#
# logFile
#
# ------------------------------------------------------------------------------------------
sub logFile {
    my ( $self, $logFile ) = @_;
    $self->{_logFile} = $logFile if defined($logFile);
    return $self->{_logFile};
}

# ------------------------------------------------------------------------------------------
#
# date
#
# ------------------------------------------------------------------------------------------
sub date {
    my ( $self, $date ) = @_;
    $self->{_date} = $date if defined($date);
    return $self->{_date};
}

# ------------------------------------------------------------------------------------------
#
# time
#
# ------------------------------------------------------------------------------------------
sub time {
   my ( $self, $time ) = @_;
   $self->{_time} = $time if defined($time);
   return $self->{_time};
}

# ------------------------------------------------------------------------------------------
#
# threadId
#
# ------------------------------------------------------------------------------------------
sub threadId {
   my ( $self, $threadId ) = @_;
   $self->{_threadId} = $threadId if defined($threadId);
   return $self->{_threadId};
}

# ------------------------------------------------------------------------------------------
#
# component
#
# ------------------------------------------------------------------------------------------
sub component {
   my ( $self, $component ) = @_;
   $self->{_component} = $component if defined($component);
   return $self->{_component};
}


# ------------------------------------------------------------------------------------------
#
# component
#
# ------------------------------------------------------------------------------------------
sub severity {
   my ( $self, $severity ) = @_;
   $self->{_severity} = $severity if defined($severity);
   return $self->{_severity};
}

# ------------------------------------------------------------------------------------------
#
# message
#
# ------------------------------------------------------------------------------------------
sub message {
   my ( $self, $message ) = @_;
   $self->{_message} = $message if defined($message);
   return $self->{_message};
}

# ------------------------------------------------------------------------------------------
#
# messageArray
#
# ------------------------------------------------------------------------------------------
sub messageArray {
   my ( $self, $max ) = @_;
   
	my @entryArray = split( '\n', $self->{_message} );
	my $arrayCount = @entryArray;
   my @array;

	my $i=0;
	my $total = $max;

	if ( ! $total or ( $total and  $total  > $arrayCount ) ) {
		$total = $arrayCount;
	}
	
	for ($i=0; $i<$total; $i++) {
		push(@array, $entryArray[$i] . "\n" );
	}	
	
   return @array;
}

# ------------------------------------------------------------------------------------------
#
# logText
#
# ------------------------------------------------------------------------------------------
sub logText {
   my ( $self, $logText ) = @_;
   $self->{_logText} = $logText if defined($logText);
   return $self->{_logText};
}

# ------------------------------------------------------------------------------------------
#
# getText
#
# ------------------------------------------------------------------------------------------
sub getText {
   my ( $self, $max ) = @_;

	my @entryArray = split( '\n', $self->logText );
	my $arrayCount = @entryArray;
   my @array;

	my $i=0;
	my $total = $max;

	if ( ! $total or ( $total and  $total  > $arrayCount ) ) {
		$total = $arrayCount;
	}
	
	for ($i=0; $i<$total; $i++) {
		push(@array, $entryArray[$i] . "\n" );
	}		

   return "@array";
}


# ------------------------------------------------------------------------------------------
#
# jsessionId
#
# ------------------------------------------------------------------------------------------
sub jsessionId {
   my ( $self, $jsessionId ) = @_;
   $self->{_jsessionId} = $jsessionId if defined($jsessionId);
   return $self->{_jsessionId};
}

# ------------------------------------------------------------------------------------------
#
# dateTime
#
# ------------------------------------------------------------------------------------------
sub dateTime {
   my ( $self, $dateTime ) = @_;
   $self->{_dateTime} = $dateTime if defined($dateTime);
   return $self->{_dateTime};
}


# ------------------------------------------------------------------------------------------
#
# print
#
# ------------------------------------------------------------------------------------------
sub print {
   my ($self) = @_;
   print $self->{_logText};
}


# ------------------------------------------------------------------------------------------
#
# debug
#
# ------------------------------------------------------------------------------------------
sub debug {

   my ($self) = @_;

   print "-------------------------------------------------------------\n";
   print "DateTime:   " . $self->DateTime->datetime . "\n";
   print "Date:       " . $self->date . "\n";
   print "Time:       " . $self->time . "\n";
   print "ThreadId:   " . $self->threadId   . "\n";
   print "JsessionId: " . $self->jsessionId . "\n";
   print "Component:  " . $self->component  . "\n";
   print "Severity:   " . $self->severity   . "\n";
   print "Message:    " . $self->message    . "\n";
}


1;
