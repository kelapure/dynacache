#!/usr/bin/perl

package WAS::DefaultLogFormat;

use strict;
use warnings;
use Data::Dumper;
use DateTime;

use WAS::LogEntry;
use WAS::LogFormat;

our @ISA = qw(WAS::LogFormat);


# ------------------------------------------------------------------------------------------
#
# parse
#
# ------------------------------------------------------------------------------------------
sub parse {

   my $self  = shift;
   my @array = @{(shift)};
   my $entry;

   my $logText;

   # there should be a better way to do this;
   foreach my $l (@array) { $logText = $logText . $l; }

   # read first line
   my $header = shift(@array);

   if ( $header ) {

      if ( ! $self->isNewEntry($header) ) {
         print "-----> ERROR: Error on parsing. The following text is not a valid log entry:\n";
         print "$header\n";
      }

      $entry =  eval { new WAS::LogEntry(); }  or die ($@);

      $entry->logText($logText);

      #
      # Parse the first line
      #
      # [3/1/07 14:47:07:516 EST] 00000058 CommerceSrvr  I com.ibm.wca.IdResGen.Handler.HandlerToken executeFetch Info: SELECT VERSIONSPC_ID FROM WCP.VERSIONSPC WHERE ITEMSPC_ID = 17969 AND ITEMVERSN_ID = 10110
      my ($date,$time,$timezone,$threadId, $component,$severity,$message) = ( $header =~ /^\[(\S+)\s(\S+)\s(\S+)\]\s+(\S+)\s(\S+)\s+(\S)\s(.*)/ );

      $message = $message . "\n";
      foreach my $l (@array) {
         $message = $message . $l;
      }

      if ( ! $time or ! $timezone or ! $threadId ) {
         print "------------------------------------------------------------------------------------\n";
         print "ERROR: Failed to parse entry:\n";
         # print "time: [$time] timezone [$timezone] threadId [$threadId]\n";
         print $header ;
         print "------------------------------------------------------------------------------------\n";
         exit;
      }
      
      # Format time
		my ($month,$day,$year)                  = ( $date =~ /^(\d+)\/(\d+)\/(\d+)/ );
		my ($hour,$minute,$second,$millisecond) = ( $time =~ /^(\d+):(\d+):(\d+):(\d+)/ );
		
		my $dt = DateTime->new( year   => 2000+$year,
			                     month  => $month,
			                     day    => $day,
			                     hour   => $hour,
			                     minute => $minute,
			                     second => $second,
			                     nanosecond => ($millisecond*1000000)
			                     );

		$entry->dateTime($dt);
      $entry->date($date);
      $entry->time($time . " " . $timezone );
      $entry->threadId($threadId);
      $entry->component($component);
      $entry->severity($severity);
      $entry->message($message);

      #$entry->debug;
   }

   return $entry;
}


1;
