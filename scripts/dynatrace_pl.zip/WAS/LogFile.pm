#!/usr/bin/perl

package WAS::LogFile;

use strict;
use warnings;
use Data::Dumper;
#use diagnostics;

use WAS::FormatDiscovery;


# ------------------------------------------------------------------------------------------
#
# new
#
# ------------------------------------------------------------------------------------------
sub new {

   my ( $class, $logfile ) = @_;
   my $handle;

   open $handle, "<" . $logfile  or die "Error, unable to open $logfile, $!\n";

   my $self = {
      _logfile    => $logfile,
      _handle     => $handle,
      _filebuffer => undef
   };

   # creates new parser
   $self->{_parser} = eval { findFormat WAS::FormatDiscovery( $logfile ); }  or die ($@);

   bless $self, $class;

   return $self;
}


# ------------------------------------------------------------------------------------------
#
# close
#
# ------------------------------------------------------------------------------------------
sub close {

   my ($self) = @_;
   close $self->{_handle};
}

# ------------------------------------------------------------------------------------------
#
# parser
#
# ------------------------------------------------------------------------------------------
sub parser {

   my ( $self ) = @_;
   return $self->{_parser};
}

# ------------------------------------------------------------------------------------------
#
# nextEntry
#
# ------------------------------------------------------------------------------------------
sub nextEntry {

   my ($self) = @_;
   my @entry;

   my $log = $self->{_handle};

   # if we have one line in buffer we need to process it first;
   if ( $self->{_filebuffer} ) {
      # buffered line should always be a new entry - this is a double check
      if ( $self->{_filebuffer} =~ m/^\[/ ) {
         push(@entry, $self->{_filebuffer} );
         $self->{_filebuffer} = undef;
      }
   }

   while( <$log> ) {
   	
   	# Correlation Identity: 028bad70-53fa-11dc-97d5-82e346d12fcc
   	
      # if we find a new date we need to
      # step one line back and return the entry
      if ( $self->parser->isNewEntry($_) and @entry ) {
         # buffer line for next request
         $self->{_filebuffer} = $_;
         return $self->parser->parse(\@entry);
      }

      my $size = @entry;
      if ( ( $size == 0 and $self->parser->isNewEntry($_) ) or $size > 0 ) {
         push(@entry, $_ );
      }
   }

   if ( @entry ) {
      return $self->parser->parse(\@entry);
   }

   return;
}

1;

