#!/usr/bin/perl

package WAS::SearsLogFormat;

use strict;
use warnings;
use Data::Dumper;

use WAS::LogEntry;

our @ISA = qw(WAS::LogFormat);


#  \n     A newline
#  \t     A tab
#  \w     Any alphanumeric (word) character.
#              The same as [a-zA-Z0-9_]
#  \W     Any non-word character.
#         The same as [^a-zA-Z0-9_]
#  \d     Any digit. The same as [0-9]
#  \D     Any non-digit. The same as [^0-9]
#  \s     Any whitespace character: space,
#         tab, newline, etc
#  \S     Any non-whitespace character
#  \b     A word boundary, outside [] only
#  \B     No word boundary


# ------------------------------------------------------------------------------------------
#
# parse
#
# ------------------------------------------------------------------------------------------
sub parse {

   my $self  = shift;
   my @array = @{(shift)};
   my $entry;

   my $logText;

   # there should be a better way to do this;
   foreach my $l (@array) { $logText = $logText . $l; }

   # read first line
   my $header = shift(@array);

   if ( $header ) {

      if ( ! $self->isNewEntry($header) ) {
         print "-----> ERROR: Error on parsing. The following text is not a valid log entry:\n";
         print "$header\n";
      }

      $entry =  eval { new WAS::LogEntry(); }  or die ($@);

      $entry->logText($logText);

      #
      # Parse the first line
      #
      # [6/5/07 11:07:58:690 CDT]  INFO  0000003a  ETMKFyE2xmkVtdGmqKYrO3y  com.shc.ecom.shoppingcart  Order Id 131501
      my ($date,$time,$timezone,$severity, $threadId, $jsessionId, $component, $message ) = ( $header =~ /^\[(\S+)\s(\S+)\s(\S+)\]\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)/ );

      if ( ! $time or ! $timezone or ! $threadId ) {

         # try this format instead
         # [8/27/07 18:35:14:62 CDT]  INFO  00000095    com.shc.ecom.orderprocess.paymentauth.controllercmd.OrderPaymentControllerCmdImpl  orderReleaseEnumcom.ibm.ivj.ejb.runtime.AccessBeanEnumeration@2402e3f2

         ($date,$time,$timezone,$severity, $threadId, $component, $message ) = ( $header =~ /^\[(\S+)\s(\S+)\s(\S+)\]\s+(\S+)\s+(\S+)\s\s\s\s(\S+)\s+(.+)/ );

         $jsessionId = "";

         if ( ! $time or ! $timezone or ! $threadId ) {

            print "------------------------------------------------------------------------------------\n";
            print "ERROR: Failed to parse entry:\n";
            # print "time: [$time] timezone [$timezone] threadId [$threadId]\n";
            print $header ;
            print "------------------------------------------------------------------------------------\n";
            exit;
         }
      }

      $message = $message . "\n";
      foreach my $l (@array) {
         $message = $message . $l;
      }



      $entry->date($date);
      $entry->time($time . " " . $timezone );
      $entry->severity($severity);
      $entry->threadId($threadId);
      $entry->jsessionId($jsessionId);
      $entry->component($component);
      $entry->message($message);

      # $entry->debug;

   }

   return $entry;
}


1;
